# 01 — Fondations

Cette version stabilise l'architecture du futur LM Studio.

## Décisions

- Un seul projet.
- Des packages séparés par responsabilité.
- Un DSL unique.
- Un Object Model commun.
- Des renderers indépendants.
- Une timeline centrale à venir.
- Des widgets LM-C01 à LM-C0n comme modules.

## Prochaine étape

2. LM DSL complet.
