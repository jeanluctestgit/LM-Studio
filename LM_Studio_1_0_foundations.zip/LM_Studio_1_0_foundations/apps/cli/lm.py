
from pathlib import Path
import argparse, json, sys

ROOT = Path(__file__).resolve().parents[2]
for package in (ROOT / "packages").iterdir():
    src = package
    sys.path.insert(0, str(src))

from lm_dsl.parser import parse_lm
from lm_assets.manager import LMAssetManager
from lm_render_html.renderer import render_html
from lm_render_svg.renderer import render_svg

class LMCompiler:
    def __init__(self, root):
        self.root = Path(root)
        self.assets = LMAssetManager(self.root)

    def load(self, source):
        doc = parse_lm(Path(source).read_text(encoding="utf-8"), str(source))
        doc = self.assets.resolve_document(doc)
        doc.warnings = [f"Asset manquant : {a.kind}/{a.ref}" for a in doc.card.assets if not a.exists]
        return doc

    def inspect(self, source):
        return json.dumps(self.load(source).to_dict(), ensure_ascii=False, indent=2)

    def build(self, source, html=False, svg=False):
        doc = self.load(source)
        outputs = []
        if html:
            out = self.root / "output/html" / (Path(source).stem + ".html")
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(render_html(doc), encoding="utf-8")
            outputs.append(out)
        if svg:
            out = self.root / "output/svg" / (Path(source).stem + ".svg")
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(render_svg(doc), encoding="utf-8")
            outputs.append(out)
        return outputs

def main():
    parser = argparse.ArgumentParser(prog="lm")
    sub = parser.add_subparsers(dest="command")

    p_inspect = sub.add_parser("inspect")
    p_inspect.add_argument("source")

    p_build = sub.add_parser("build")
    p_build.add_argument("source")
    p_build.add_argument("--html", action="store_true")
    p_build.add_argument("--svg", action="store_true")

    sub.add_parser("assets")

    args = parser.parse_args()
    compiler = LMCompiler(ROOT)

    if args.command == "inspect":
        print(compiler.inspect(args.source))
    elif args.command == "build":
        outs = compiler.build(args.source, html=args.html, svg=args.svg)
        print("\\n".join(str(o) for o in outs))
    elif args.command == "assets":
        print(compiler.assets.summary())
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
