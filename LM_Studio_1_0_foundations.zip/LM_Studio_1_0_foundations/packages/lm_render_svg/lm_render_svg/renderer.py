
from html import escape
from lm_widgets.widgets import create_widgets

def render_svg(document):
    card = document.card
    tempo = card.tempo.label() if card.tempo else ""
    widgets = create_widgets(document)
    y = 205
    blocks = []
    for widget in widgets:
        blocks.append(widget.render_svg(80, y))
        y += 84

    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="800" viewBox="0 0 1200 800">
<title>{escape(card.card_id)} - {escape(card.title)}</title>
<rect width="1200" height="800" fill="#f8fafc"/>
<rect x="32" y="32" width="1136" height="736" rx="24" fill="white" stroke="#d1d5db" stroke-width="3"/>
<rect x="72" y="62" width="145" height="52" rx="10" fill="#0f4fb3"/>
<text x="94" y="96" font-family="Arial" font-size="22" font-weight="700" fill="white">{escape(card.card_id)}</text>
<text x="245" y="96" font-family="Arial" font-size="32" font-weight="700" fill="#111827">{escape(card.title)}</text>
<text x="80" y="150" font-family="Arial" font-size="16" fill="#6b7280">{escape(card.family)} - {escape(card.phase)} - {escape(tempo)}</text>
<line x1="80" y1="178" x2="1120" y2="178" stroke="#d1d5db" stroke-width="2"/>
{''.join(blocks)}
</svg>"""
