
from lm_core.model import LMDocument, LMCard, LMTempo, LMWidgetSpec, LMAssetRef

def unquote(value: str) -> str:
    value = value.strip()
    return value[1:-1] if len(value) >= 2 and value[0] == '"' and value[-1] == '"' else value

def parse_lm(text: str, source_path: str = "") -> LMDocument:
    card = None

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue

        parts = line.split(maxsplit=1)
        key = parts[0]
        rest = parts[1] if len(parts) > 1 else ""

        if key == "Card":
            card = LMCard(card_id=rest.strip())
        elif card is None:
            raise ValueError("Le fichier doit commencer par Card <id>")
        elif key == "Title":
            card.title = unquote(rest)
        elif key == "Family":
            card.family = unquote(rest)
        elif key == "Phase":
            card.phase = unquote(rest)
        elif key == "Status":
            card.status = unquote(rest)
        elif key == "Version":
            card.version = unquote(rest)
        elif key == "Tempo":
            card.tempo = LMTempo.parse(rest)
            card.properties["Tempo"] = rest
        elif key == "Use":
            p = rest.split(maxsplit=1)
            component = p[0]
            argument = unquote(p[1]) if len(p) > 1 else None
            card.widget_specs.append(LMWidgetSpec(component, argument))

            if component in {"Audio", "InteractiveAudio"} and argument:
                card.asset_refs.append(LMAssetRef("audio", argument, "playback"))
            if component in {"LilyPond", "LilyPondHighlight"} and argument:
                card.asset_refs.append(LMAssetRef("lilypond", argument, "score"))
            if component == "Timeline" and argument:
                card.properties["Timeline"] = argument
        elif key == "Export":
            card.exports.append(rest.strip())
        else:
            card.properties[key] = unquote(rest)

    if card is None:
        raise ValueError("Aucune carte trouvée")

    return LMDocument(source_path=source_path, card=card)
