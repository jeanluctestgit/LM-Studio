
from html import escape
from lm_widgets.widgets import create_widgets

CSS = """
body{font-family:Arial,Helvetica,sans-serif;background:#f8fafc;margin:32px;color:#111827}
.lm-card{background:white;border:2px solid #d1d5db;border-radius:22px;padding:28px;max-width:1040px;margin:auto}
.lm-badge{display:inline-block;background:#0f4fb3;color:white;padding:8px 14px;border-radius:8px;font-weight:bold}
.lm-meta{color:#6b7280}
.lm-layout{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.lm-widget{border:1px solid #d1d5db;border-left:7px solid var(--lm-color);border-radius:14px;padding:14px;background:#fff}
.lm-timeline{grid-column:1/-1}
.lm-timeline-track{position:relative;display:grid;grid-template-columns:repeat(8,1fr);gap:4px;padding-top:18px}
.lm-time-cell{border:1px solid #d1d5db;border-radius:12px;padding:12px 6px;text-align:center;background:#f9fafb}
.lm-time-cell.attack b{color:var(--lm-color)}
.lm-cursor{position:absolute;top:0;left:0;width:3px;height:100%;background:var(--lm-color)}
"""

JS = """
let cursorIndex = 0;
setInterval(() => {
  document.querySelectorAll('.lm-timeline').forEach(t => {
    const cells = [...t.querySelectorAll('.lm-time-cell')];
    const cursor = t.querySelector('.lm-cursor');
    if(!cells.length) return;
    cells.forEach((c,i)=>c.style.background = i===cursorIndex%cells.length ? '#dbeafe' : '#f9fafb');
    if(cursor) cursor.style.left = ((cursorIndex%cells.length)/cells.length*100)+'%';
  });
  cursorIndex++;
}, 500);
"""

def render_html(document):
    card = document.card
    tempo = card.tempo.label() if card.tempo else ""
    widgets = "\\n".join(w.render_html(document) for w in create_widgets(document))
    return f"""<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>{escape(card.card_id)} - {escape(card.title)}</title>
<style>{CSS}</style>
<script>{JS}</script>
</head>
<body>
<main class="lm-card">
<div class="lm-badge">{escape(card.card_id)}</div>
<h1>{escape(card.title)}</h1>
<p class="lm-meta">{escape(card.family)} - {escape(card.phase)} - {escape(tempo)}</p>
<section class="lm-layout">{widgets}</section>
</main>
</body>
</html>"""
