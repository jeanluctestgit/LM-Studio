
from pathlib import Path
from lm_core.model import LMAsset

KIND_DIRS = {
    "audio": "assets/audio",
    "lilypond": "assets/lilypond",
    "svg": "assets/svg",
    "guitar": "assets/guitar",
    "icons": "assets/icons",
}

HTML_REL = {
    "audio": "../../assets/audio",
    "lilypond": "../../assets/lilypond",
    "svg": "../../assets/svg",
    "guitar": "../../assets/guitar",
    "icons": "../../assets/icons",
}

class LMAssetManager:
    def __init__(self, root: Path):
        self.root = Path(root)

    def resolve_document(self, document):
        document.card.assets = []
        for ref in document.card.asset_refs:
            folder = KIND_DIRS.get(ref.kind, "assets")
            html_folder = HTML_REL.get(ref.kind, "../../assets")
            path = self.root / folder / ref.ref
            document.card.assets.append(
                LMAsset(
                    kind=ref.kind,
                    ref=ref.ref,
                    role=ref.role,
                    path=str(path),
                    html_src=f"{html_folder}/{ref.ref}",
                    exists=path.exists(),
                )
            )
        return document

    def summary(self):
        lines = ["Assets:"]
        for kind, rel in KIND_DIRS.items():
            folder = self.root / rel
            folder.mkdir(parents=True, exist_ok=True)
            for f in sorted(folder.rglob("*")):
                if f.is_file():
                    lines.append(f"- {kind}: {f.name}")
        return "\\n".join(lines)
