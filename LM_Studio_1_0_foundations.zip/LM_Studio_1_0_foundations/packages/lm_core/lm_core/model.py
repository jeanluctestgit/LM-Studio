
from dataclasses import dataclass, field, asdict

@dataclass
class LMTempo:
    min_bpm: int | None = None
    max_bpm: int | None = None

    @classmethod
    def parse(cls, value: str):
        value = value.strip()
        if ".." in value:
            a, b = value.split("..", 1)
            return cls(int(a), int(b))
        try:
            bpm = int(value)
            return cls(bpm, bpm)
        except Exception:
            return cls()

    def label(self) -> str:
        if self.min_bpm and self.max_bpm:
            if self.min_bpm == self.max_bpm:
                return f"{self.min_bpm} BPM"
            return f"{self.min_bpm} - {self.max_bpm} BPM"
        return ""

@dataclass
class LMAssetRef:
    kind: str
    ref: str
    role: str | None = None

@dataclass
class LMAsset:
    kind: str
    ref: str
    role: str | None = None
    path: str | None = None
    html_src: str | None = None
    exists: bool = False

@dataclass
class LMWidgetSpec:
    component: str
    argument: str | None = None

@dataclass
class LMCard:
    card_id: str
    title: str = ""
    family: str = ""
    phase: str = ""
    status: str = "draft"
    version: str = "1.0"
    properties: dict = field(default_factory=dict)
    tempo: LMTempo | None = None
    asset_refs: list[LMAssetRef] = field(default_factory=list)
    assets: list[LMAsset] = field(default_factory=list)
    widget_specs: list[LMWidgetSpec] = field(default_factory=list)
    exports: list[str] = field(default_factory=list)

    def to_dict(self):
        return asdict(self)

@dataclass
class LMDocument:
    source_path: str
    card: LMCard
    warnings: list[str] = field(default_factory=list)

    def to_dict(self):
        return asdict(self)
