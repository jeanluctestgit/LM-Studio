
from dataclasses import dataclass
from html import escape

@dataclass
class LMWidget:
    component: str
    argument: str | None = None
    label: str = "Widget"
    color: str = "#6b7280"

    def render_html(self, document=None):
        arg = f" - {escape(str(self.argument))}" if self.argument else ""
        return f"<section class='lm-widget' style='--lm-color:{self.color}'><h3>{escape(self.label)}</h3><p>{arg}</p></section>"

    def render_svg(self, x, y, w=1040, h=68):
        arg = f" - {escape(str(self.argument))}" if self.argument else ""
        return f"""<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="white" stroke="#d1d5db"/>
<rect x="{x}" y="{y}" width="10" height="{h}" rx="5" fill="{self.color}"/>
<text x="{x+28}" y="{y+42}" font-family="Arial" font-size="18" font-weight="700" fill="#111827">{escape(self.label)}</text>
<text x="{x+260}" y="{y+42}" font-family="Arial" font-size="15" fill="#6b7280">{arg}</text>"""

MAP = {
    "Pyramid": ("Pyramide rythmique", "#d97706"),
    "Timeline": ("Timeline pédagogique", "#2563eb"),
    "LilyPond": ("Notation LilyPond", "#111827"),
    "InteractiveAudio": ("Lecteur audio interactif", "#0f6b2f"),
    "Count": ("Comptage", "#6b21a8"),
    "Gesture": ("Geste instrumental", "#ea580c"),
}

class LMTimelineWidget(LMWidget):
    def render_html(self, document=None):
        arg = self.argument or "4/4:8:X......."
        parts = arg.split(":")
        measure, subdivision, pattern = parts if len(parts) == 3 else ("4/4", "8", arg)
        labels = ["1", "&", "2", "&", "3", "&", "4", "&"]
        cells = []
        for i, ch in enumerate(pattern):
            hit = "attack" if ch.upper() == "X" else ""
            lab = labels[i] if i < len(labels) else str(i+1)
            cells.append(f"<div class='lm-time-cell {hit}' data-step='{i}'><span>{lab}</span><b>{escape(ch)}</b></div>")
        return f"""<section class='lm-widget lm-timeline' style='--lm-color:{self.color}' data-pattern='{escape(pattern)}'>
<h3>{escape(self.label)} - {escape(measure)} / {escape(subdivision)}</h3>
<div class='lm-timeline-track'><div class='lm-cursor'></div>{''.join(cells)}</div>
</section>"""

def create_widget(spec):
    label, color = MAP.get(spec.component, (spec.component, "#6b7280"))
    if spec.component == "Timeline":
        return LMTimelineWidget(spec.component, spec.argument, label, color)
    return LMWidget(spec.component, spec.argument, label, color)

def create_widgets(document):
    return [create_widget(spec) for spec in document.card.widget_specs]
