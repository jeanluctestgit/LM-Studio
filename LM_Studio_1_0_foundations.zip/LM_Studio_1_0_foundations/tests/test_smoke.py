# Smoke test manuel

python apps/cli/lm.py inspect examples/Volume0/LM-C05-B_Tresillo.lm
python apps/cli/lm.py build examples/Volume0/LM-C05-B_Tresillo.lm --html --svg
